/* Informática Básica
 *
 * @author Samuel Megolla Expósito
 * @date dic 1 2022
 * @brief Parity of the number of divisors, indica el total de la suma del numero de los divisores e indica si son pares o impares. 
 */
#include<iostream>
using namespace std;

int main(){
 int number{0},counter{0};
 while(cin>>number){
   for(int i = 1; i<=number; i++){
     if(number%i==0){
       counter++;
     }
   if(counter%2==0){
     cout<<number<<": even"<<endl;
   }else{
     cout<<number<<": odd"<<endl;
   }
   }
 }
  return 0;
}

