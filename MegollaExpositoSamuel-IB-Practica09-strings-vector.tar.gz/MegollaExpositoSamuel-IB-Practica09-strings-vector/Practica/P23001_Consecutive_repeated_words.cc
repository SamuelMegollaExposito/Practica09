/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Samuel Megolla Expósito
 * @date diciembre 1 2022
 * @brief el programa recibe como entrada una cadena de palabras y comprara el u * numero de veces que se repita la primera palabra.
 */
#include <iostream>
using namespace std;

int main(){
  string palabra, cadena;
  cin>>palabra;
  int counter{1},total{1};
  while(cin>>cadena){
    if(cadena==palabra){
      counter++;
    }else{
       if(counter>total){
         total=counter;
       }
      counter=0;
    }
  }
  cout<<max(counter,total)<<endl;
}

