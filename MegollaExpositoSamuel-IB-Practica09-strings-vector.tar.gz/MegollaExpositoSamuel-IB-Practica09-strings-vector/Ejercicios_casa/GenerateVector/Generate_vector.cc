#include<iostream>
#include<vector>
#include<string>
#include<stdlib.h>
#include<time.h>
#include<random>
#include<iomanip>

using namespace std;

std::vector<double> GenerateVector(const int size, const double lower, const double upper);

int main(int argc, char *argv[]){
	
	if(argc!=4){
		cout<<"Error: Numero de parametros erroneos."<<endl;
	}
	double size = std::stod(argv[1]);
	double lower = std::stod(argv[2]);
	double upper = std::stod(argv[3]);


	std::vector<double> my_vector = GenerateVector(size-1 ,lower,upper);
	for (const auto& value: my_vector) {
		  std::cout << "Component: "<<setprecision(2)<<fixed<< value << std::endl;
	}








return 0;
}
std::vector<double> GenerateVector(const int size, const double lower, const double upper){
	
	std::vector<double> my_new_vector;

	for(int i = 0; i<=size; i++){
		std::random_device rd;
	        std::default_random_engine eng(rd());
       	        std::uniform_real_distribution<double> distr(lower, upper);
		double num = distr(eng);
		my_new_vector.push_back(num);
	}
	return my_new_vector;

}
